# GENERATED VERSION FILE
# TIME: Fri Oct 23 14:37:50 2026
__version__ = '1.4.2'
__gitsha__ = 'unknown'
version_info = (1, 4, 2)
